(function(){

  angular.module('psqca')
    .constant("BaseUrl", "https://psqca.herokuapp.com/api/");
    //.constant("BaseUrl", "http://localhost:3000/api/");

})();
